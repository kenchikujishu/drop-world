drop world — animal-cats-vol-01 (DWG)

これは差し替え用のダミーです。実データの zip を
public/downloads/animal-cats-vol-01/animal-cats-vol-01-dwg.zip に置き換えてください。

Placeholder archive. Replace with the real DWG files.
https://drop-world.com
