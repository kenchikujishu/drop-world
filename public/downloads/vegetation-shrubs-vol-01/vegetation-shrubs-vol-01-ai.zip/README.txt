drop world — vegetation-shrubs-vol-01 (AI)

これは差し替え用のダミーです。実データの zip を
public/downloads/vegetation-shrubs-vol-01/vegetation-shrubs-vol-01-ai.zip に置き換えてください。

Placeholder archive. Replace with the real AI files.
https://drop-world.com
