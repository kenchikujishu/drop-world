drop world — vegetation-shrubs-vol-01 (DWG)

これは差し替え用のダミーです。実データの zip を
public/downloads/vegetation-shrubs-vol-01/vegetation-shrubs-vol-01-dwg.zip に置き換えてください。

Placeholder archive. Replace with the real DWG files.
https://drop-world.com
