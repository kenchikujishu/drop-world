drop world — people-workers-vol-01 (AI)

これは差し替え用のダミーです。実データの zip を
public/downloads/people-workers-vol-01/people-workers-vol-01-ai.zip に置き換えてください。

Placeholder archive. Replace with the real AI files.
https://drop-world.com
